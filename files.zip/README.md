# 🎙 podcast-feed

Your personal daily podcast recommender — Entrepreneurship & AI.  
Hosted on GitHub Pages. Opens on mobile. No login, no cost.

---

## 🚀 Setup (5 minutes)

### Step 1 — Create the repo
1. Go to [github.com/new](https://github.com/new)
2. Repository name: `podcast-feed`
3. Set to **Public** ✅ (required for free GitHub Pages)
4. Click **Create repository**

### Step 2 — Upload the file
1. In your new repo, click **"uploading an existing file"**
2. Drag and drop `index.html`
3. Click **Commit changes**

### Step 3 — Enable GitHub Pages
1. Go to repo **Settings** → **Pages** (left sidebar)
2. Under "Source" → select **Deploy from a branch**
3. Branch: **main** · Folder: **/ (root)**
4. Click **Save**

### Step 4 — Get your link
- Wait ~60 seconds
- Your live URL will be:  
  `https://YOUR-USERNAME.github.io/podcast-feed`
- Open this on your phone and bookmark it 📱

---

## 📱 Add to Home Screen (Mobile)

**iPhone:** Open link in Safari → Share → "Add to Home Screen"  
**Android:** Open in Chrome → Menu → "Add to Home Screen"

It'll appear like an app on your home screen.

---

## 🔄 Updating Later

To update the app, just replace `index.html` in the repo:
1. Go to your repo on GitHub
2. Click `index.html` → pencil icon (Edit)
3. Paste new content → Commit

Changes go live in ~30 seconds.
